import './App.css';
import React, { useEffect, useState } from "react";
import Header from './Components/UI/Header/Header';
import InfiniteGrid from './Components/Simulator/InfiniteGrid/InfiniteGrid';
import Menu from './Components/UI/Menu/Menu/Menu';
import PropMenu from './Components/UI/PropMenu/PropMenu/PropMenu';
import { v4 as uuid } from 'uuid';
import { defaultSettings } from './Additional/DefaltSettings.js'
import { useStrictMode } from 'react-konva';
import { calculate } from './Additional/Calculate';
import Error from './Components/UI/Error/Error';

// fix errors delete wires
// arthmetic
// changeValue fix
// check test
// backend
// авторизация
// get tests
// save tests results
 

function App() {
  useStrictMode(true);
  const [simElements, setSimElements] = useState(() => {
    let raw = window.localStorage.getItem('simElements') || '[]'
    raw = raw.replace('null,', '')
    raw = raw.replace('null', '')
    return JSON.parse(raw)
    }
  );
  
  const [errorMessage, setErrorMessage] = useState("")

  const handleValueChange = (se) => {
    try{
      setSimElements(calculate(se))
      setErrorMessage("")
    }
    catch (ex) {
      if(typeof ex === "string")
        setErrorMessage(ex)
      console.log(ex)
    }
  }
  useEffect(() => {
      window.localStorage.setItem('simElements', JSON.stringify(simElements));
    }, [simElements]
  )
  const addComponent = (type) => {
    const se = simElements ? simElements.slice() : [];
    const id_obj = {id: uuid().slice(0,8)};
    se.push(
      Object.assign(id_obj, structuredClone(defaultSettings[type]))
    )
    setSimElements(se);
  }
  

  const removeComponent = (id) => {
    const se = simElements ? simElements.filter((x) => x.id !== id) : [];
    for(let i = 0; i < se.length; i++) {
      se[i].out = se[i].out.filter((x) => x !== id)
      se[i].in = se[i].in.filter((x) => x !== id)
      if(se[i].control) se[i].control = se[i].control.filter((x) => x !== id)
    }
    setSimElements(se)
  }

  const addWire = (inId, outId) => {
    const se = simElements ? simElements.slice() : [];
    const inEl = se.find(x => x.id === inId)
    const outEl = se.find(x => x.id === outId)
    const plexors = ['MS', 'DMS', 'CD', 'DC',]
    if(inEl.in.indexOf(outId) === -1 || true) {
      let add = false
      for(let i = 0; i < inEl.in.length; i++){
        if(typeof inEl.in[i] === 'undefined'){
          
          inEl.in[i] = outId
          add = true
          break
        }
      }
      
      if(!add)
        se.find(x => x.id === inId).in.push(outId);
    }
    if(outEl.out.indexOf(inId) === -1 || true) {
      let add = false
      for(let i = 0; i < outEl.out.length; i++){
        if(typeof outEl.out[i] === 'undefined'){
          // console.log(i)
          outEl.out[i] = inId
          add = true
          break
        }
          
      }
      if(!add)
        outEl.out.push(inId);
    }
    setSimElements(se);
    handleValueChange(simElements)
  }

  const addControlWire = (inId, outId) => {
    const se = simElements ? simElements.slice() : [];
    if(se.find(x => x.id === inId).control.indexOf(outId) === -1){
      se.find(x => x.id === inId).control.push(outId);
    }
    if(se.find(x => x.id === outId).out.indexOf(inId) === -1){
      se.find(x => x.id === outId).out.push(inId);
    }
    setSimElements(se);
    handleValueChange(simElements)
  }


  const removeWire = (id1, id2, indexOut, indexIn) => {
    const se = simElements ? simElements.slice() : [];
    const el1 = se.find(x => x.id === id1)
    const el2 = se.find(x => x.id === id2)
    if(el1){
      delete el1.out[el1.out.indexOf(id2)]
      delete el1.in[el1.in.indexOf(id2)]
    }
    if(el2){
      delete el2.out[el2.out.indexOf(id1)]
      delete el2.in[el2.in.indexOf(id1)]
    }
    if(el1.prop.type === 'MS' || el1.prop.type === 'DMS'){

      if(se.find(x => x.id === id1).control[0] === id2){
        se.find(x => x.id === id1).control = []
      } 
    }
    if(el2.prop.type === 'MS' || el2.prop.type === 'DMS'){     
      if(el2.control.indexOf(id1) !== -1){
        el2.control = []
      }
    }
    setSimElements(se);
    handleValueChange(simElements)
  }

  const changeComponentProperties = (e, key) => {
    const se = simElements ? simElements.slice() : [];
    se.find((x) => x.focusElement === true).mutableProp[key] = parseInt(e.target.value) ? parseInt(e.target.value) : 0;
    if(key === 'value'){
      e.target.value ? 
      se.find((x) => x.focusElement === true).mutableProp[key] = parseInt(e.target.value) > Math.pow(2, se.find((x) => x.focusElement === true).mutableProp.bitWidth) - 1 ?
      0 : parseInt(e.target.value)
      :
      se.find((x) => x.focusElement === true).mutableProp[key] = 0
      handleValueChange(simElements)
    }
    else if(key === 'bitWidth'){
      e.target.value ? 
      se.find((x) => x.focusElement === true).mutableProp[key] = parseInt(e.target.value) > 16 ? 16 : parseInt(e.target.value)
      :
      se.find((x) => x.focusElement === true).mutableProp[key] = 0
      handleValueChange(simElements)
    }
    else if(key === 'inputSize' || key === 'controlSize'){
      const el = se.find((x) => x.focusElement === true)
      el.in.forEach(id => {
        const tmp = se.find((x) => x.id === id)
        tmp.out = tmp.out.filter(a => a !== el.id)
      });
      el.in = []
      if(key === 'controlSize'){
        se.find((x) => x.focusElement === true).mutableProp[key] = (se.find((x) => x.focusElement === true).mutableProp[key] + 1) % 3 + 1
        const tmp = se.find((x) => x.id === el.control[0])
        if(tmp) tmp.out = tmp.out.filter(a => a !== el.id)
        el.control = []
      }
      
    }
    setSimElements(se);
  }

  return ( 
    <div >
      <Header/>
      <InfiniteGrid simElements={simElements} setSimElements={setSimElements} addWire={addWire} addControlWire={addControlWire} removeWire={removeWire} handleValueChange={handleValueChange}/>
      <Menu addComponent={addComponent} Title="Элементы схемы"/>

      <PropMenu 
        Title="Свойства" 
        focusElement={simElements.find(item => item.focusElement === true)} 
        removeComponent={removeComponent}
        changeComponentProperties={changeComponentProperties}
      />
      {
        errorMessage !== "" ? 
          <Error text={errorMessage}></Error>
          :
          null
      }
     
    </div>
  );
}

export default App;


