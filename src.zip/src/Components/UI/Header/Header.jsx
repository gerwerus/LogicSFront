import React from 'react';
import HeaderButton from '../HeaderButton/HeaderButton';
import classes from './Header.module.css';


const Header = function ({children, ...props}) {
    return (
        <header {...props} className={classes.myHdr}>
            {
                <div>
                    <HeaderButton>Сохранить проект</HeaderButton>
                    <HeaderButton>Загрузить</HeaderButton>
                    <HeaderButton>Авторизоваться</HeaderButton>
                </div>
            }
        </header>     
    )
}

export default Header;